<?php
/**
 * Zlaark Hero Fresh — a clean, light-theme hero with a pastel green/yellow
 * accent system: eyebrow pill, bold headline, description, two pill CTAs and
 * a framed image sitting on a soft blob backdrop.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use Elementor\Controls_Manager;
use Elementor\Icons_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Box_Shadow;
use Elementor\Utils;

class Zlaark_Hero_Fresh_Widget extends Zlaark_Widget_Base {

	public function get_name() {
		return 'zlaark_hero_fresh';
	}

	public function get_title() {
		return __( 'Zlaark Hero Fresh', 'zlaark-deals-pro' );
	}

	public function get_icon() {
		return 'eicon-slider-full-screen';
	}

	public function get_keywords() {
		return array( 'hero', 'banner', 'header', 'cta', 'light', 'fresh', 'zlaark' );
	}

	protected function register_controls() {
		$this->content_controls();
		$this->buttons_controls();
		$this->media_controls();
		$this->layout_controls();
		$this->style_controls();
		$this->animation_controls( false );
		$this->motion_section();
	}

	/* ---------------------------------------------------------------- content */

	private function content_controls() {
		$this->start_controls_section(
			'section_content',
			array( 'label' => __( 'Content', 'zlaark-deals-pro' ) )
		);

		$this->add_control(
			'eyebrow',
			array(
				'label'       => __( 'Eyebrow Pill', 'zlaark-deals-pro' ),
				'type'        => Controls_Manager::TEXT,
				'default'     => __( 'Trusted by growing brands', 'zlaark-deals-pro' ),
				'label_block' => true,
			)
		);

		$this->add_control(
			'eyebrow_icon',
			array(
				'label'     => __( 'Eyebrow Icon', 'zlaark-deals-pro' ),
				'type'      => Controls_Manager::ICONS,
				'condition' => array( 'eyebrow!' => '' ),
				'default'   => array(
					'value'   => 'fas fa-seedling',
					'library' => 'fa-solid',
				),
			)
		);

		$this->add_control(
			'title',
			array(
				'label'       => __( 'Title', 'zlaark-deals-pro' ),
				'type'        => Controls_Manager::TEXTAREA,
				'rows'        => 3,
				'default'     => __( 'Transform your vision into digital', 'zlaark-deals-pro' ),
				'label_block' => true,
				'description' => __( 'Each word animates in on its own.', 'zlaark-deals-pro' ),
			)
		);

		$this->add_control(
			'title_highlight',
			array(
				'label'       => __( 'Highlighted Words', 'zlaark-deals-pro' ),
				'type'        => Controls_Manager::TEXT,
				'default'     => __( 'excellence', 'zlaark-deals-pro' ),
				'label_block' => true,
				'description' => __( 'Appended to the title with an accent fill.', 'zlaark-deals-pro' ),
			)
		);

		$this->add_control(
			'title_tag',
			array(
				'label'   => __( 'Title HTML Tag', 'zlaark-deals-pro' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'h1',
				'options' => array(
					'h1'  => 'H1',
					'h2'  => 'H2',
					'h3'  => 'H3',
					'div' => 'div',
				),
			)
		);

		$this->add_control(
			'description',
			array(
				'label'   => __( 'Description', 'zlaark-deals-pro' ),
				'type'    => Controls_Manager::TEXTAREA,
				'rows'    => 4,
				'default' => __( 'Empowering brands with innovative designs and tailored business strategies to thrive and grow in the ever-evolving digital landscape.', 'zlaark-deals-pro' ),
			)
		);

		$this->end_controls_section();
	}

	private function buttons_controls() {
		$this->start_controls_section(
			'section_buttons',
			array( 'label' => __( 'Buttons', 'zlaark-deals-pro' ) )
		);

		$this->add_control(
			'primary_text',
			array(
				'label'   => __( 'Primary Button', 'zlaark-deals-pro' ),
				'type'    => Controls_Manager::TEXT,
				'default' => __( 'View Portfolio', 'zlaark-deals-pro' ),
			)
		);

		$this->add_control(
			'primary_link',
			array(
				'label'   => __( 'Primary Link', 'zlaark-deals-pro' ),
				'type'    => Controls_Manager::URL,
				'default' => array( 'url' => '#' ),
			)
		);

		$this->add_control(
			'secondary_text',
			array(
				'label'     => __( 'Secondary Button', 'zlaark-deals-pro' ),
				'type'      => Controls_Manager::TEXT,
				'default'   => __( 'Watch Reels', 'zlaark-deals-pro' ),
				'separator' => 'before',
			)
		);

		$this->add_control(
			'secondary_link',
			array(
				'label'     => __( 'Secondary Link', 'zlaark-deals-pro' ),
				'type'      => Controls_Manager::URL,
				'condition' => array( 'secondary_text!' => '' ),
			)
		);

		$this->add_control(
			'secondary_icon',
			array(
				'label'     => __( 'Secondary Icon', 'zlaark-deals-pro' ),
				'type'      => Controls_Manager::ICONS,
				'condition' => array( 'secondary_text!' => '' ),
				'default'   => array(
					'value'   => 'fas fa-play',
					'library' => 'fa-solid',
				),
			)
		);

		$this->end_controls_section();
	}

	private function media_controls() {
		$this->start_controls_section(
			'section_media',
			array( 'label' => __( 'Media', 'zlaark-deals-pro' ) )
		);

		$this->add_control(
			'image',
			array(
				'label'   => __( 'Image', 'zlaark-deals-pro' ),
				'type'    => Controls_Manager::MEDIA,
				'default' => array( 'url' => Utils::get_placeholder_image_src() ),
			)
		);

		$this->add_control(
			'heading_badge',
			array(
				'label'     => __( 'Floating Badge', 'zlaark-deals-pro' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
			)
		);

		$this->add_control(
			'badge_show',
			array(
				'label'        => __( 'Show', 'zlaark-deals-pro' ),
				'type'         => Controls_Manager::SWITCHER,
				'default'      => 'yes',
				'return_value' => 'yes',
			)
		);

		$this->add_control(
			'badge_icon',
			array(
				'label'     => __( 'Icon', 'zlaark-deals-pro' ),
				'type'      => Controls_Manager::ICONS,
				'condition' => array( 'badge_show' => 'yes' ),
				'default'   => array(
					'value'   => 'fas fa-star',
					'library' => 'fa-solid',
				),
			)
		);

		$this->add_control(
			'badge_value',
			array(
				'label'     => __( 'Value', 'zlaark-deals-pro' ),
				'type'      => Controls_Manager::TEXT,
				'default'   => __( '4.9/5', 'zlaark-deals-pro' ),
				'condition' => array( 'badge_show' => 'yes' ),
			)
		);

		$this->add_control(
			'badge_label',
			array(
				'label'     => __( 'Label', 'zlaark-deals-pro' ),
				'type'      => Controls_Manager::TEXT,
				'default'   => __( 'Client rating', 'zlaark-deals-pro' ),
				'condition' => array( 'badge_show' => 'yes' ),
			)
		);

		$this->end_controls_section();
	}

	private function layout_controls() {
		$this->start_controls_section(
			'section_layout',
			array( 'label' => __( 'Layout', 'zlaark-deals-pro' ) )
		);

		$this->add_control(
			'media_side',
			array(
				'label'   => __( 'Media Side', 'zlaark-deals-pro' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'right',
				'options' => array(
					'right' => __( 'Text left / media right', 'zlaark-deals-pro' ),
					'left'  => __( 'Media left / text right', 'zlaark-deals-pro' ),
					'none'  => __( 'Text only', 'zlaark-deals-pro' ),
				),
			)
		);

		$this->max_width_control( '{{WRAPPER}} .zd-hf__inner', 1480 );

		$this->add_responsive_control(
			'gap',
			array(
				'label'      => __( 'Column Gap', 'zlaark-deals-pro' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => array( 'px' ),
				'range'      => array( 'px' => array( 'min' => 0, 'max' => 160 ) ),
				'default'    => array( 'unit' => 'px', 'size' => 64 ),
				'selectors'  => array( '{{WRAPPER}} .zd-hf__inner' => 'gap: {{SIZE}}{{UNIT}};' ),
			)
		);

		$this->end_controls_section();
	}

	/* ------------------------------------------------------------------ style */

	private function style_controls() {
		$this->start_controls_section(
			'section_style_box',
			array(
				'label' => __( 'Section', 'zlaark-deals-pro' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_responsive_control(
			'padding',
			array(
				'label'      => __( 'Padding', 'zlaark-deals-pro' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => array( 'px', 'em', '%' ),
				'default'    => array(
					'top'      => '110',
					'right'    => '40',
					'bottom'   => '110',
					'left'     => '40',
					'unit'     => 'px',
					'isLinked' => false,
				),
				'selectors'  => array(
					'{{WRAPPER}} .zd-hf' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);

		$this->add_control(
			'accent',
			array(
				'label'     => __( 'Accent — Green', 'zlaark-deals-pro' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#16a34a',
				'separator' => 'before',
				'selectors' => array( '{{WRAPPER}} .zd-hf' => '--zd-hf-accent: {{VALUE}};' ),
			)
		);

		$this->add_control(
			'accent_2',
			array(
				'label'     => __( 'Accent — Yellow', 'zlaark-deals-pro' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#eab308',
				'selectors' => array( '{{WRAPPER}} .zd-hf' => '--zd-hf-accent-2: {{VALUE}};' ),
			)
		);

		$this->add_control(
			'bg_color',
			array(
				'label'     => __( 'Background', 'zlaark-deals-pro' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#fbfdf8',
				'separator' => 'before',
				'selectors' => array( '{{WRAPPER}} .zd-hf' => '--zd-hf-bg: {{VALUE}};' ),
			)
		);

		$this->end_controls_section();

		/* Typography */
		$this->start_controls_section(
			'section_style_text',
			array(
				'label' => __( 'Typography', 'zlaark-deals-pro' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_control(
			'title_color',
			array(
				'label'     => __( 'Title Colour', 'zlaark-deals-pro' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#0f172a',
				'selectors' => array( '{{WRAPPER}} .zd-hf__title' => 'color: {{VALUE}};' ),
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'title_typography',
				'selector' => '{{WRAPPER}} .zd-hf__title',
			)
		);

		$this->add_responsive_control(
			'title_size',
			array(
				'label'      => __( 'Title Size', 'zlaark-deals-pro' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => array( 'px', 'vw' ),
				'range'      => array(
					'px' => array( 'min' => 26, 'max' => 96 ),
					'vw' => array( 'min' => 2, 'max' => 8, 'step' => 0.1 ),
				),
				'default'    => array( 'unit' => 'px', 'size' => 56 ),
				'selectors'  => array( '{{WRAPPER}} .zd-hf__title' => 'font-size: {{SIZE}}{{UNIT}};' ),
			)
		);

		$this->add_control(
			'desc_color',
			array(
				'label'     => __( 'Description Colour', 'zlaark-deals-pro' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#5b6472',
				'separator' => 'before',
				'selectors' => array( '{{WRAPPER}} .zd-hf__desc' => 'color: {{VALUE}};' ),
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'desc_typography',
				'selector' => '{{WRAPPER}} .zd-hf__desc',
			)
		);

		$this->add_responsive_control(
			'desc_width',
			array(
				'label'      => __( 'Description Max Width', 'zlaark-deals-pro' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => array( 'px', '%' ),
				'range'      => array(
					'px' => array( 'min' => 240, 'max' => 900 ),
					'%'  => array( 'min' => 20, 'max' => 100 ),
				),
				'default'    => array( 'unit' => 'px', 'size' => 540 ),
				'selectors'  => array( '{{WRAPPER}} .zd-hf__desc' => 'max-width: {{SIZE}}{{UNIT}};' ),
			)
		);

		$this->end_controls_section();

		/* Buttons */
		$this->start_controls_section(
			'section_style_buttons',
			array(
				'label' => __( 'Buttons', 'zlaark-deals-pro' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'button_typography',
				'selector' => '{{WRAPPER}} .zd-hf__btn',
			)
		);

		$this->end_controls_section();

		/* Media */
		$this->start_controls_section(
			'section_style_media',
			array(
				'label'     => __( 'Media', 'zlaark-deals-pro' ),
				'tab'       => Controls_Manager::TAB_STYLE,
				'condition' => array( 'media_side!' => 'none' ),
			)
		);

		$this->add_responsive_control(
			'media_radius',
			array(
				'label'      => __( 'Frame Radius', 'zlaark-deals-pro' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => array( 'px' ),
				'range'      => array( 'px' => array( 'min' => 0, 'max' => 60 ) ),
				'default'    => array( 'unit' => 'px', 'size' => 28 ),
				'selectors'  => array( '{{WRAPPER}} .zd-hf__frame' => 'border-radius: {{SIZE}}{{UNIT}};' ),
			)
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			array(
				'name'     => 'media_shadow',
				'selector' => '{{WRAPPER}} .zd-hf__frame',
			)
		);

		$this->end_controls_section();
	}

	private function motion_section() {
		$this->start_controls_section(
			'section_hf_motion',
			array(
				'label' => __( 'Ambient Motion', 'zlaark-deals-pro' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_control(
			'bg_blobs',
			array(
				'label'        => __( 'Soft Blobs', 'zlaark-deals-pro' ),
				'type'         => Controls_Manager::SWITCHER,
				'default'      => 'yes',
				'return_value' => 'yes',
			)
		);

		$this->add_control(
			'media_float',
			array(
				'label'        => __( 'Floating Media', 'zlaark-deals-pro' ),
				'type'         => Controls_Manager::SWITCHER,
				'default'      => 'yes',
				'return_value' => 'yes',
				'condition'    => array( 'media_side!' => 'none' ),
			)
		);

		$this->add_control(
			'media_parallax',
			array(
				'label'        => __( 'Cursor Parallax', 'zlaark-deals-pro' ),
				'type'         => Controls_Manager::SWITCHER,
				'default'      => 'yes',
				'return_value' => 'yes',
				'condition'    => array( 'media_side!' => 'none' ),
			)
		);

		$this->add_control(
			'magnetic',
			array(
				'label'        => __( 'Magnetic Buttons', 'zlaark-deals-pro' ),
				'type'         => Controls_Manager::SWITCHER,
				'default'      => 'yes',
				'return_value' => 'yes',
			)
		);

		$this->end_controls_section();
	}

	/* ----------------------------------------------------------------- render */

	protected function render() {
		$s    = $this->get_settings_for_display();
		$side = ! empty( $s['media_side'] ) ? $s['media_side'] : 'right';

		$classes = array( 'zd-hf', 'zd-hf--' . $side );
		if ( 'yes' === $s['bg_blobs'] ) {
			$classes[] = 'zd-hf--blobs';
		}

		$this->add_render_attribute( 'wrapper', 'class', $classes );
		$this->add_render_attribute( 'wrapper', 'data-zd-reveal-root', 'true' );
		$this->add_render_attribute(
			'wrapper',
			'data-zd-stagger',
			isset( $s['reveal_stagger']['size'] ) ? (int) $s['reveal_stagger']['size'] : 90
		);

		$effect    = ! empty( $s['reveal_effect'] ) ? $s['reveal_effect'] : 'rise';
		$has_media = ( 'none' !== $side ) && ! empty( $s['image']['url'] );
		?>
		<div <?php $this->print_render_attribute_string( 'wrapper' ); ?>>

			<?php if ( 'yes' === $s['bg_blobs'] ) : ?>
				<div class="zd-hf__blobs" aria-hidden="true">
					<span class="zd-hf__blob zd-hf__blob--1"></span>
					<span class="zd-hf__blob zd-hf__blob--2"></span>
				</div>
			<?php endif; ?>

			<div class="zd-hf__inner">
				<div class="zd-hf__content">
					<?php $this->render_eyebrow( $s, $effect ); ?>
					<?php $this->render_title( $s, $effect ); ?>

					<?php if ( ! empty( $s['description'] ) ) : ?>
						<div class="zd-hf__desc zd-reveal" data-zd-reveal="<?php echo esc_attr( $effect ); ?>">
							<?php echo wp_kses_post( wpautop( $s['description'] ) ); ?>
						</div>
					<?php endif; ?>

					<?php $this->render_buttons( $s, $effect ); ?>
				</div>

				<?php if ( $has_media ) : ?>
					<?php $this->render_media( $s ); ?>
				<?php endif; ?>
			</div>
		</div>
		<?php
	}

	private function render_eyebrow( $s, $effect ) {
		if ( empty( $s['eyebrow'] ) ) {
			return;
		}
		?>
		<p class="zd-hf__eyebrow zd-reveal" data-zd-reveal="<?php echo esc_attr( $effect ); ?>">
			<?php if ( ! empty( $s['eyebrow_icon']['value'] ) ) : ?>
				<span class="zd-hf__eyebrow-icon">
					<?php Icons_Manager::render_icon( $s['eyebrow_icon'], array( 'aria-hidden' => 'true' ) ); ?>
				</span>
			<?php endif; ?>
			<?php echo esc_html( $s['eyebrow'] ); ?>
		</p>
		<?php
	}

	/** Splits the title into per-word spans so each can animate on its own delay. */
	private function render_title( $s, $effect ) {
		if ( empty( $s['title'] ) && empty( $s['title_highlight'] ) ) {
			return;
		}

		$tag   = ! empty( $s['title_tag'] ) ? $s['title_tag'] : 'h1';
		$words = preg_split( '/\s+/', trim( (string) $s['title'] ), -1, PREG_SPLIT_NO_EMPTY );

		printf( '<%1$s class="zd-hf__title" data-zd-reveal="%2$s">', esc_attr( $tag ), esc_attr( $effect ) );

		foreach ( $words as $i => $word ) {
			printf(
				'<span class="zd-word" style="--zd-i:%1$d"><span>%2$s</span></span> ',
				(int) $i,
				esc_html( $word )
			);
		}

		if ( ! empty( $s['title_highlight'] ) ) {
			printf(
				'<span class="zd-word zd-hf__word--accent" style="--zd-i:%1$d"><span>%2$s</span></span>',
				count( $words ),
				esc_html( $s['title_highlight'] )
			);
		}

		printf( '</%1$s>', esc_attr( $tag ) );
	}

	private function render_buttons( $s, $effect ) {
		if ( empty( $s['primary_text'] ) && empty( $s['secondary_text'] ) ) {
			return;
		}
		?>
		<div class="zd-hf__actions zd-reveal" data-zd-reveal="<?php echo esc_attr( $effect ); ?>">
			<?php
			$this->render_button( 'solid', $s['primary_text'], $s['primary_link'], $s, null );
			$this->render_button( 'outline', $s['secondary_text'], $s['secondary_link'], $s, $s['secondary_icon'] );
			?>
		</div>
		<?php
	}

	private function render_button( $variant, $text, $link, $s, $icon ) {
		if ( empty( $text ) ) {
			return;
		}

		$key     = 'btn_' . $variant;
		$classes = array( 'zd-hf__btn', 'zd-hf__btn--' . $variant );
		if ( 'yes' === $s['magnetic'] ) {
			$classes[] = 'zd-magnetic';
		}

		$this->add_render_attribute( $key, 'class', $classes );
		if ( ! empty( $link['url'] ) ) {
			$this->add_link_attributes( $key, $link );
		}
		?>
		<a <?php $this->print_render_attribute_string( $key ); ?>>
			<?php if ( ! empty( $icon['value'] ) ) : ?>
				<span class="zd-hf__btn-icon" aria-hidden="true">
					<?php Icons_Manager::render_icon( $icon, array( 'aria-hidden' => 'true' ) ); ?>
				</span>
			<?php endif; ?>
			<span class="zd-hf__btn-label"><?php echo esc_html( $text ); ?></span>
		</a>
		<?php
	}

	private function render_media( $s ) {
		$classes = array( 'zd-hf__media', 'zd-reveal' );
		if ( 'yes' === $s['media_float'] ) {
			$classes[] = 'zd-hf__media--float';
		}
		if ( 'yes' === $s['media_parallax'] ) {
			$classes[] = 'zd-parallax';
		}
		?>
		<div class="<?php echo esc_attr( implode( ' ', $classes ) ); ?>" data-zd-reveal="zoom">
			<span class="zd-hf__media-glow" aria-hidden="true"></span>

			<div class="zd-hf__frame">
				<img src="<?php echo esc_url( $s['image']['url'] ); ?>"
					alt="<?php echo esc_attr( zlaark_deals_media_alt( $s['image'] ) ); ?>" />
			</div>

			<?php if ( 'yes' === $s['badge_show'] ) : ?>
				<div class="zd-hf__badge">
					<?php if ( ! empty( $s['badge_icon']['value'] ) ) : ?>
						<span class="zd-hf__badge-icon">
							<?php Icons_Manager::render_icon( $s['badge_icon'], array( 'aria-hidden' => 'true' ) ); ?>
						</span>
					<?php endif; ?>
					<span class="zd-hf__badge-body">
						<span class="zd-hf__badge-value"><?php echo esc_html( $s['badge_value'] ); ?></span>
						<span class="zd-hf__badge-label"><?php echo esc_html( $s['badge_label'] ); ?></span>
					</span>
				</div>
			<?php endif; ?>
		</div>
		<?php
	}
}
