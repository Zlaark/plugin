/* =========================================================================
   Zlaark Deals — motion runtime
   Scroll reveals, count-ups, rating rings, score bars, cursor tilt,
   magnetic buttons, hero parallax and the category filter tabs.
   Everything is idempotent so Elementor can re-render a widget safely.
   ========================================================================= */
( function () {
	'use strict';

	var DONE = 'zdInit';
	var reduced = window.matchMedia && window.matchMedia( '(prefers-reduced-motion: reduce)' ).matches;

	function once( el ) {
		if ( el.dataset[ DONE ] ) {
			return false;
		}
		el.dataset[ DONE ] = '1';
		return true;
	}

	function each( scope, selector, fn ) {
		Array.prototype.forEach.call( scope.querySelectorAll( selector ), fn );
	}

	/* ------------------------------------------------------------- reveals */

	/**
	 * Stagger is applied per reveal root so a grid of cards cascades, while
	 * two separate widgets on the page stay independent of each other.
	 */
	function applyStagger( root ) {
		var step = parseInt( root.getAttribute( 'data-zd-stagger' ), 10 );
		if ( isNaN( step ) || step <= 0 ) {
			return;
		}

		var items = root.querySelectorAll( '[data-zd-reveal]' );
		Array.prototype.forEach.call( items, function ( el, i ) {
			// Nested reveals (a card inside a revealed group) keep their own
			// delay rather than inheriting the parent's slot.
			if ( ! el.style.getPropertyValue( '--zd-delay' ) ) {
				el.style.setProperty( '--zd-delay', i * step + 'ms' );
			}
		} );
	}

	var revealObserver = 'IntersectionObserver' in window
		? new IntersectionObserver( function ( entries, obs ) {
			entries.forEach( function ( entry ) {
				if ( ! entry.isIntersecting ) {
					return;
				}
				entry.target.classList.add( 'is-in' );
				obs.unobserve( entry.target );
			} );
		}, { threshold: 0.12, rootMargin: '0px 0px -8% 0px' } )
		: null;

	function initReveals( scope ) {
		each( scope, '[data-zd-reveal-root]', function ( root ) {
			applyStagger( root );
		} );

		each( scope, '[data-zd-reveal]', function ( el ) {
			if ( ! once( el ) ) {
				return;
			}
			if ( ! revealObserver || reduced ) {
				el.classList.add( 'is-in' );
				return;
			}
			revealObserver.observe( el );
		} );
	}

	/* ---------------------------------------------------------- count-ups */

	function easeOutQuart( t ) {
		return 1 - Math.pow( 1 - t, 4 );
	}

	function countUp( el ) {
		var target = parseFloat( el.getAttribute( 'data-zd-count' ) );
		if ( isNaN( target ) ) {
			return;
		}

		var decimals = parseInt( el.getAttribute( 'data-zd-decimals' ), 10 ) || 0;
		var duration = parseInt( el.getAttribute( 'data-zd-duration' ), 10 ) || 1500;

		if ( reduced ) {
			el.textContent = target.toFixed( decimals );
			return;
		}

		var start = null;

		function frame( now ) {
			if ( start === null ) {
				start = now;
			}
			var progress = Math.min( ( now - start ) / duration, 1 );
			el.textContent = ( target * easeOutQuart( progress ) ).toFixed( decimals );
			if ( progress < 1 ) {
				requestAnimationFrame( frame );
			}
		}

		requestAnimationFrame( frame );
	}

	/* ------------------------------------------- rings, bars and counters */

	/** One observer drives every "animate when seen" element that isn't a reveal. */
	var valueObserver = 'IntersectionObserver' in window
		? new IntersectionObserver( function ( entries, obs ) {
			entries.forEach( function ( entry ) {
				if ( ! entry.isIntersecting ) {
					return;
				}
				var el = entry.target;
				obs.unobserve( el );

				if ( el.hasAttribute( 'data-zd-count' ) ) {
					countUp( el );
				} else if ( el.hasAttribute( 'data-zd-bar' ) ) {
					el.style.width = Math.max( 0, Math.min( 100, parseFloat( el.getAttribute( 'data-zd-bar' ) ) ) ) + '%';
				} else if ( el.classList.contains( 'zd-ring' ) ) {
					el.classList.add( 'is-in' );
				}
			} );
		}, { threshold: 0.35 } )
		: null;

	function watch( el ) {
		if ( ! once( el ) ) {
			return;
		}
		if ( ! valueObserver ) {
			// No observer support: jump straight to the finished state.
			if ( el.hasAttribute( 'data-zd-count' ) ) {
				var t = parseFloat( el.getAttribute( 'data-zd-count' ) );
				var d = parseInt( el.getAttribute( 'data-zd-decimals' ), 10 ) || 0;
				el.textContent = isNaN( t ) ? '' : t.toFixed( d );
			} else if ( el.hasAttribute( 'data-zd-bar' ) ) {
				el.style.width = parseFloat( el.getAttribute( 'data-zd-bar' ) ) + '%';
			} else {
				el.classList.add( 'is-in' );
			}
			return;
		}
		valueObserver.observe( el );
	}

	function initValues( scope ) {
		each( scope, '.zd-ring', function ( ring ) {
			// The dash offset the bar animates to, derived from the percentage.
			var pct = parseFloat( ring.getAttribute( 'data-zd-ring' ) ) || 0;
			var circ = parseFloat( getComputedStyle( ring ).getPropertyValue( '--zd-ring-circ' ) ) || 163;
			ring.style.setProperty( '--zd-ring-target', ( circ * ( 1 - pct / 100 ) ).toFixed( 2 ) );
			watch( ring );
		} );

		each( scope, '[data-zd-count]', watch );
		each( scope, '[data-zd-bar]', watch );
	}

	/* ------------------------------------------------------ pointer motion */

	var MAX_TILT = 7;

	function initTilt( scope ) {
		if ( reduced ) {
			return;
		}

		each( scope, '.zd-tilt', function ( card ) {
			if ( ! once( card ) ) {
				return;
			}

			var frame = null;

			card.addEventListener( 'pointermove', function ( e ) {
				if ( e.pointerType === 'touch' || frame ) {
					return;
				}
				frame = requestAnimationFrame( function () {
					frame = null;
					var box = card.getBoundingClientRect();
					var x = ( e.clientX - box.left ) / box.width - 0.5;
					var y = ( e.clientY - box.top ) / box.height - 0.5;
					card.style.setProperty( '--zd-ry', ( x * MAX_TILT ).toFixed( 2 ) + 'deg' );
					card.style.setProperty( '--zd-rx', ( -y * MAX_TILT ).toFixed( 2 ) + 'deg' );
				} );
			} );

			card.addEventListener( 'pointerenter', function ( e ) {
				if ( e.pointerType !== 'touch' ) {
					card.classList.add( 'is-hover' );
				}
			} );

			card.addEventListener( 'pointerleave', function () {
				card.classList.remove( 'is-hover' );
				card.style.setProperty( '--zd-rx', '0deg' );
				card.style.setProperty( '--zd-ry', '0deg' );
			} );
		} );
	}

	function initMagnetic( scope ) {
		if ( reduced ) {
			return;
		}

		each( scope, '.zd-magnetic', function ( btn ) {
			if ( ! once( btn ) ) {
				return;
			}

			var frame = null;

			btn.addEventListener( 'pointermove', function ( e ) {
				if ( e.pointerType === 'touch' || frame ) {
					return;
				}
				frame = requestAnimationFrame( function () {
					frame = null;
					var box = btn.getBoundingClientRect();
					var x = ( e.clientX - box.left - box.width / 2 ) * 0.28;
					var y = ( e.clientY - box.top - box.height / 2 ) * 0.4;
					btn.style.setProperty( '--zd-mx', x.toFixed( 1 ) + 'px' );
					btn.style.setProperty( '--zd-my', y.toFixed( 1 ) + 'px' );
				} );
			} );

			btn.addEventListener( 'pointerenter', function ( e ) {
				if ( e.pointerType !== 'touch' ) {
					btn.classList.add( 'is-hover' );
				}
			} );

			btn.addEventListener( 'pointerleave', function () {
				btn.classList.remove( 'is-hover' );
				btn.style.setProperty( '--zd-mx', '0px' );
				btn.style.setProperty( '--zd-my', '0px' );
			} );
		} );
	}

	/** Hero media drifts a few pixels against the pointer across the section. */
	function initParallax( scope ) {
		if ( reduced ) {
			return;
		}

		each( scope, '.zd-parallax', function ( media ) {
			if ( ! once( media ) ) {
				return;
			}

			var host = media.closest( '.zd-hero' ) || media.parentElement;
			if ( ! host ) {
				return;
			}

			var frame = null;

			host.addEventListener( 'pointermove', function ( e ) {
				if ( e.pointerType === 'touch' || frame ) {
					return;
				}
				frame = requestAnimationFrame( function () {
					frame = null;
					var box = host.getBoundingClientRect();
					var x = ( e.clientX - box.left ) / box.width - 0.5;
					var y = ( e.clientY - box.top ) / box.height - 0.5;
					media.style.setProperty( '--zd-px', ( x * -22 ).toFixed( 1 ) + 'px' );
					media.style.setProperty( '--zd-py', ( y * -16 ).toFixed( 1 ) + 'px' );
				} );
			} );

			host.addEventListener( 'pointerleave', function () {
				media.style.setProperty( '--zd-px', '0px' );
				media.style.setProperty( '--zd-py', '0px' );
			} );
		} );
	}

	/* --------------------------------------------------------- filter tabs */

	function moveIndicator( tabs, btn ) {
		var indicator = tabs.querySelector( '.zd-tabs__indicator' );
		if ( ! indicator ) {
			return;
		}
		indicator.style.width = btn.offsetWidth + 'px';
		indicator.style.transform = 'translateX(' + btn.offsetLeft + 'px)';
	}

	function initTabs( scope ) {
		each( scope, '.zd-tabs', function ( tabs ) {
			if ( ! once( tabs ) ) {
				return;
			}

			var deals = tabs.closest( '.zd-deals' );
			var grid = deals ? deals.querySelector( '.zd-grid' ) : null;
			var buttons = tabs.querySelectorAll( '.zd-tabs__btn' );

			var active = tabs.querySelector( '.zd-tabs__btn.is-active' ) || buttons[ 0 ];
			if ( active ) {
				// Fonts can still be loading, which would size the pill wrong.
				requestAnimationFrame( function () {
					moveIndicator( tabs, active );
				} );
			}

			window.addEventListener( 'resize', function () {
				var current = tabs.querySelector( '.zd-tabs__btn.is-active' );
				if ( current ) {
					moveIndicator( tabs, current );
				}
			} );

			Array.prototype.forEach.call( buttons, function ( btn ) {
				btn.addEventListener( 'click', function () {
					Array.prototype.forEach.call( buttons, function ( b ) {
						b.classList.remove( 'is-active' );
						b.setAttribute( 'aria-selected', 'false' );
					} );
					btn.classList.add( 'is-active' );
					btn.setAttribute( 'aria-selected', 'true' );
					moveIndicator( tabs, btn );

					if ( ! grid ) {
						return;
					}

					var filter = btn.getAttribute( 'data-zd-filter' );
					each( grid, '.zd-card', function ( card ) {
						var terms = ( card.getAttribute( 'data-zd-terms' ) || '' ).split( /\s+/ );
						var show = filter === 'all' || terms.indexOf( filter ) !== -1;
						card.classList.toggle( 'is-filtered-out', ! show );
					} );
				} );
			} );
		} );
	}

	/* ----------------------------------------------------------------- boot */

	function init( scope ) {
		scope = scope || document;
		initReveals( scope );
		initValues( scope );
		initTilt( scope );
		initMagnetic( scope );
		initParallax( scope );
		initTabs( scope );
	}

	window.ZlaarkDeals = { init: init };

	if ( document.readyState === 'loading' ) {
		document.addEventListener( 'DOMContentLoaded', function () {
			init( document );
		} );
	} else {
		init( document );
	}

	// Elementor re-renders widgets in the editor and lazy-mounts them on the
	// front end, so re-run against each element as it becomes ready.
	window.addEventListener( 'elementor/frontend/init', function () {
		if ( ! window.elementorFrontend || ! window.elementorFrontend.hooks ) {
			return;
		}
		[
			'zlaark_hero',
			'zlaark_deals',
			'zlaark_top_picks',
			'zlaark_compare',
			'zlaark_stats',
			'zlaark_marquee'
		].forEach( function ( name ) {
			window.elementorFrontend.hooks.addAction(
				'frontend/element_ready/' + name + '.default',
				function ( $scope ) {
					init( $scope && $scope[ 0 ] ? $scope[ 0 ] : document );
				}
			);
		} );
	} );
} )();
