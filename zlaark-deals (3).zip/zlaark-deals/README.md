# Zlaark Deals

Six animated Elementor widgets plus a **Deals** manager in the WordPress sidebar. Built as a more polished answer to the ecommerce-platforms.com homepage pattern: ranked top picks, a scorecard comparison, a trust-stat strip and a logo marquee, all driven by one set of deals you enter once.

## Install

1. Copy the `zlaark-deals` folder into `wp-content/plugins/`.
2. Activate **Zlaark Deals** in *Plugins*.
3. Two categories are created for you: **Discount Deals** and **Web Hosting**.

Elementor 3.5+ is required for the widgets. The Deals manager works without it.

## Adding deals

**Zlaark Deals → Add Deal** in the sidebar. One deal feeds every widget:

| Field | Used by |
|---|---|
| Title | all widgets |
| Deal Image / Logo | Deals Grid, Top Picks, Comparison, Marquee |
| Tagline | Deals Grid, Top Picks, Comparison (rows) |
| Pricing / Original Price | Deals Grid, Top Picks, Comparison |
| Badge | Deals Grid (animated corner ribbon) |
| Rank Label | Top Picks (e.g. *Editor's Choice*) |
| Rating (0–10) | the animated rating ring |
| Highlights | Top Picks — one per line, staggered checklist |
| Score Breakdown | Comparison — `Label\|9.4` per line, drives the bars |
| Button Text / URL / new tab | all card widgets |
| Deal Categories | how every widget filters |

Categories live at **Zlaark Deals → Categories**. Use *Page Attributes → Order* for manual sorting.

## The widgets

All six sit under the **Zlaark Deals** category in the Elementor panel, and each one has a **Motion** section in the Style tab: scroll-reveal effect (rise / fade / zoom / slide / 3D flip), stagger delay, 3D cursor tilt, hover shine sweep and a rotating conic border glow.

### Zlaark Hero
Aurora background with drifting colour blooms, a panning grid, five floating orbs, a word-by-word masked title reveal, a gradient highlight phrase with a self-drawing underline, a pulsing status pill, magnetic buttons, counting stat strip, and a counter-rotating double ring behind a parallaxing, bobbing image. Four layouts; every colour, size and motion toggle is exposed.

### Zlaark Deals Grid
Your deal cards, filtered by category. Optional front-end **category tabs** with a sliding pill indicator. Cards tilt toward the cursor, lift, sweep a shine across, and light a rotating gradient border. Logos push forward in 3D on hover.

### Zlaark Top Picks
Ranked cards with a counter-rotating gradient medal, an animated rating ring that draws its arc and counts its number up, a staggered highlights checklist, and an optional gradient-bordered spotlight on the #1 pick.

### Zlaark Comparison
Scorecards or compact rows built from the Score Breakdown field. Bars fill on scroll with a travelling sheen, numbers count up, rows lift and logos rotate on hover.

### Zlaark Stats
Trust numbers that roll up from zero when scrolled into view, with an orbiting accent ring and optional animated gradient fill on the digits.

### Zlaark Logo Marquee
Seamless infinite scroll in either direction, sourced from a deal category or a manual list. Pauses on hover, greyscale until hover, faded edges.

## Differentiating by category

Every widget has a multi-select **Category** control. Drop the Deals Grid twice on a page, pick *Discount Deals* in one and *Web Hosting* in the other, and you get the two-column layout from your reference — leave the Heading empty and each block titles itself from its category.

## Accessibility & performance

- Full `prefers-reduced-motion` support: all ambient loops, reveals, tilts and parallax switch off while the layout stays intact.
- CSS and JS are registered but only enqueued on pages that actually use a widget.
- Reveals and counters use a single shared `IntersectionObserver`; pointer effects are `requestAnimationFrame`-throttled.

## Structure

```
zlaark-deals/
├── zlaark-deals.php                        bootstrap, constants, assets
├── uninstall.php
├── includes/
│   ├── class-zlaark-deals-post-type.php    CPT, taxonomy, default terms, columns
│   ├── class-zlaark-deals-meta.php         Deal Details meta box, save, parsers
│   └── class-zlaark-deals-elementor.php    widget category + registration
├── widgets/
│   ├── class-zlaark-widget-base.php        shared motion + query controls
│   ├── class-zlaark-hero-widget.php
│   ├── class-zlaark-deals-widget.php
│   ├── class-zlaark-top-picks-widget.php
│   ├── class-zlaark-compare-widget.php
│   ├── class-zlaark-stats-widget.php
│   └── class-zlaark-marquee-widget.php
└── assets/
    ├── css/frontend.css                    layout + the whole motion system
    ├── css/admin.css
    ├── js/frontend.js                      reveal/count/tilt/magnetic/tabs runtime
    └── js/admin.js
```
