<?php
/**
 * Plugin Name: DealCraft — Elementor Deals & Hero
 * Description: Custom Elementor widgets (Hero, Deals Grid) plus a "Deals" manager in the WP sidebar with categories, image, title, pricing and button fields.
 * Version:     1.0.0
 * Author:      DealCraft
 * Text Domain: dealcraft
 * Requires PHP: 7.4
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'DEALCRAFT_VERSION', '1.0.0' );
define( 'DEALCRAFT_FILE', __FILE__ );
define( 'DEALCRAFT_PATH', plugin_dir_path( __FILE__ ) );
define( 'DEALCRAFT_URL', plugin_dir_url( __FILE__ ) );

/** Post type + taxonomy slugs used across the plugin. */
define( 'DEALCRAFT_CPT', 'dealcraft_deal' );
define( 'DEALCRAFT_TAX', 'dealcraft_category' );

require_once DEALCRAFT_PATH . 'includes/class-dealcraft-post-type.php';
require_once DEALCRAFT_PATH . 'includes/class-dealcraft-meta.php';
require_once DEALCRAFT_PATH . 'includes/class-dealcraft-elementor.php';

final class DealCraft {

	/** @var DealCraft|null */
	private static $instance = null;

	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	private function __construct() {
		DealCraft_Post_Type::init();
		DealCraft_Meta::init();
		DealCraft_Elementor::init();

		add_action( 'wp_enqueue_scripts', array( $this, 'register_frontend_assets' ) );
		add_action( 'admin_enqueue_scripts', array( $this, 'admin_assets' ) );
	}

	public function register_frontend_assets() {
		wp_register_style(
			'dealcraft-frontend',
			DEALCRAFT_URL . 'assets/css/frontend.css',
			array(),
			DEALCRAFT_VERSION
		);
		// Registered only — the widgets pull it in via get_style_depends(), so
		// pages without a DealCraft widget stay clean.
	}

	public function admin_assets( $hook ) {
		$screen = get_current_screen();
		if ( ! $screen || DEALCRAFT_CPT !== $screen->post_type ) {
			return;
		}

		wp_enqueue_media();
		wp_enqueue_style(
			'dealcraft-admin',
			DEALCRAFT_URL . 'assets/css/admin.css',
			array(),
			DEALCRAFT_VERSION
		);
		wp_enqueue_script(
			'dealcraft-admin',
			DEALCRAFT_URL . 'assets/js/admin.js',
			array( 'jquery' ),
			DEALCRAFT_VERSION,
			true
		);
		wp_localize_script(
			'dealcraft-admin',
			'DealCraftAdmin',
			array(
				'chooseImage' => __( 'Choose deal image', 'dealcraft' ),
				'useImage'    => __( 'Use this image', 'dealcraft' ),
			)
		);
	}
}

/**
 * Activation: register the CPT/taxonomy, seed the two default categories and
 * flush rewrite rules so the archive URLs work immediately.
 */
function dealcraft_activate() {
	DealCraft_Post_Type::register_post_type();
	DealCraft_Post_Type::register_taxonomy();
	DealCraft_Post_Type::seed_default_terms();
	flush_rewrite_rules();
}
register_activation_hook( __FILE__, 'dealcraft_activate' );

function dealcraft_deactivate() {
	flush_rewrite_rules();
}
register_deactivation_hook( __FILE__, 'dealcraft_deactivate' );

add_action( 'plugins_loaded', array( 'DealCraft', 'instance' ) );
