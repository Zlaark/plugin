<?php
/**
 * Removes every DealCraft deal, category and option when the plugin is deleted.
 */

if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}

$dealcraft_cpt = 'dealcraft_deal';
$dealcraft_tax = 'dealcraft_category';

// The plugin's own hooks never run during uninstall, so the taxonomy has to be
// registered here before get_terms()/wp_delete_term() will accept it.
register_taxonomy( $dealcraft_tax, array( $dealcraft_cpt ), array( 'public' => false ) );

$deals = get_posts(
	array(
		'post_type'      => $dealcraft_cpt,
		'post_status'    => 'any',
		'numberposts'    => -1,
		'fields'         => 'ids',
		'suppress_filters' => true,
	)
);

foreach ( $deals as $deal_id ) {
	wp_delete_post( $deal_id, true );
}

$terms = get_terms(
	array(
		'taxonomy'   => $dealcraft_tax,
		'hide_empty' => false,
		'fields'     => 'ids',
	)
);

if ( ! is_wp_error( $terms ) ) {
	foreach ( $terms as $term_id ) {
		wp_delete_term( $term_id, $dealcraft_tax );
	}
}

delete_option( 'dealcraft_defaults_seeded' );
