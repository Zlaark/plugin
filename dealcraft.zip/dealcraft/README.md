# DealCraft — Elementor Deals & Hero

A WordPress plugin that adds two editable Elementor widgets and a **Deals** manager in the WP admin sidebar.

## Install

1. Copy the `dealcraft` folder into `wp-content/plugins/`.
2. Activate **DealCraft — Elementor Deals & Hero** in *Plugins*.
3. On activation the two default categories are created: **Discount Deals** and **Web Hosting**.

Elementor 3.5+ is required for the widgets. The Deals manager works without Elementor.

## Adding deals

**DealCraft → Add Deal** in the sidebar. Each deal has:

| Field | Notes |
|---|---|
| Title | The deal name, e.g. *ClickUp — Project Management* |
| Deal Image / Logo | Picked from the media library |
| Pricing | Free text — `$2.59/mo`, `Free Forever`, … |
| Original Price | Optional, rendered struck through |
| Badge | Optional corner ribbon |
| Button Text / URL | Plus an "open in new tab" toggle |
| Deal Categories | Which category the deal belongs to |

Categories are managed at **DealCraft → Categories** — add as many as you need beyond the two defaults. Use *Page Attributes → Order* on each deal to control the manual sort order.

## Elementor widgets

Both live under the **DealCraft** category in the Elementor panel.

### DealCraft Hero

Editable content: eyebrow, title (with selectable HTML tag), description, image, primary + secondary buttons, and four layouts (image right / image left / centered / text only). Style tab covers background, padding, radius, gap, typography and colours for every text element, button colours and hover states, and image size/radius/shadow.

### DealCraft Deals

Pulls deals from the CPT.

- **Category** — multi-select; leave empty to show every category. This is how you split *Discount Deals* from *Web Hosting* on the same page: drop the widget twice and pick a different category in each.
- **Number of Deals**, **Order By** (manual / date / title / random), **Order**
- **Heading** — leave empty and the selected category name is used
- Responsive **Columns** and **Gap**
- Toggles for image, pricing, button, and `rel="nofollow sponsored"` on affiliate links
- Full Style tab for the card (background, border, radius, padding, shadow), title/price typography and colours, and the button.

## Structure

```
dealcraft/
├── dealcraft.php                          bootstrap, constants, asset registration
├── includes/
│   ├── class-dealcraft-post-type.php      CPT, taxonomy, default terms, admin columns
│   ├── class-dealcraft-meta.php           Deal Details meta box + save + data helper
│   └── class-dealcraft-elementor.php      widget category + widget registration
├── widgets/
│   ├── class-dealcraft-hero-widget.php
│   └── class-dealcraft-deals-widget.php
└── assets/
    ├── css/frontend.css
    ├── css/admin.css
    └── js/admin.js
```

## Uninstall

Deleting the plugin removes its deals, categories and settings — see `uninstall.php`.
