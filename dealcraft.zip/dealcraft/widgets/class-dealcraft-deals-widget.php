<?php
/**
 * DealCraft Deals Grid — renders deals from the CPT, filtered by category.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Box_Shadow;
use Elementor\Group_Control_Border;

class DealCraft_Deals_Widget extends Widget_Base {

	public function get_name() {
		return 'dealcraft_deals';
	}

	public function get_title() {
		return __( 'DealCraft Deals', 'dealcraft' );
	}

	public function get_icon() {
		return 'eicon-price-list';
	}

	public function get_categories() {
		return array( 'dealcraft' );
	}

	public function get_keywords() {
		return array( 'deals', 'offers', 'discount', 'pricing', 'coupon', 'dealcraft' );
	}

	public function get_style_depends() {
		return array( 'dealcraft-frontend' );
	}

	protected function register_controls() {
		$this->query_controls();
		$this->display_controls();
		$this->style_controls();
	}

	/* ------------------------------------------------------------------ query */

	private function query_controls() {
		$this->start_controls_section(
			'section_query',
			array(
				'label' => __( 'Deals', 'dealcraft' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			)
		);

		$categories = DealCraft_Post_Type::get_category_options();

		if ( empty( $categories ) ) {
			$this->add_control(
				'no_categories_notice',
				array(
					'type'            => Controls_Manager::RAW_HTML,
					'raw'             => __( 'No deal categories found yet. Add some under <strong>DealCraft &rarr; Categories</strong>.', 'dealcraft' ),
					'content_classes' => 'elementor-panel-alert elementor-panel-alert-warning',
				)
			);
		}

		$this->add_control(
			'category',
			array(
				'label'       => __( 'Category', 'dealcraft' ),
				'type'        => Controls_Manager::SELECT2,
				'multiple'    => true,
				'label_block' => true,
				'options'     => $categories,
				'default'     => array(),
				'description' => __( 'Leave empty to show deals from every category.', 'dealcraft' ),
			)
		);

		$this->add_control(
			'limit',
			array(
				'label'   => __( 'Number of Deals', 'dealcraft' ),
				'type'    => Controls_Manager::NUMBER,
				'min'     => 1,
				'max'     => 60,
				'default' => 6,
			)
		);

		$this->add_control(
			'orderby',
			array(
				'label'   => __( 'Order By', 'dealcraft' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'menu_order',
				'options' => array(
					'menu_order' => __( 'Manual order (page attributes)', 'dealcraft' ),
					'date'       => __( 'Date published', 'dealcraft' ),
					'title'      => __( 'Title', 'dealcraft' ),
					'rand'       => __( 'Random', 'dealcraft' ),
				),
			)
		);

		$this->add_control(
			'order',
			array(
				'label'     => __( 'Order', 'dealcraft' ),
				'type'      => Controls_Manager::SELECT,
				'default'   => 'ASC',
				'options'   => array(
					'ASC'  => __( 'Ascending', 'dealcraft' ),
					'DESC' => __( 'Descending', 'dealcraft' ),
				),
				'condition' => array( 'orderby!' => 'rand' ),
			)
		);

		$this->end_controls_section();
	}

	/* ---------------------------------------------------------------- display */

	private function display_controls() {
		$this->start_controls_section(
			'section_display',
			array(
				'label' => __( 'Layout', 'dealcraft' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			)
		);

		$this->add_control(
			'show_heading',
			array(
				'label'        => __( 'Show Section Heading', 'dealcraft' ),
				'type'         => Controls_Manager::SWITCHER,
				'default'      => 'yes',
				'label_on'     => __( 'Show', 'dealcraft' ),
				'label_off'    => __( 'Hide', 'dealcraft' ),
				'return_value' => 'yes',
			)
		);

		$this->add_control(
			'heading',
			array(
				'label'       => __( 'Heading', 'dealcraft' ),
				'type'        => Controls_Manager::TEXT,
				'default'     => __( 'Discount Deals 2025', 'dealcraft' ),
				'label_block' => true,
				'description' => __( 'Leave empty to use the selected category name.', 'dealcraft' ),
				'condition'   => array( 'show_heading' => 'yes' ),
			)
		);

		$this->add_responsive_control(
			'columns',
			array(
				'label'          => __( 'Columns', 'dealcraft' ),
				'type'           => Controls_Manager::SELECT,
				'default'        => '1',
				'tablet_default' => '1',
				'mobile_default' => '1',
				'options'        => array(
					'1' => '1',
					'2' => '2',
					'3' => '3',
					'4' => '4',
				),
				'selectors'      => array(
					'{{WRAPPER}} .dealcraft-deals__grid' => 'grid-template-columns: repeat({{VALUE}}, minmax(0, 1fr));',
				),
			)
		);

		$this->add_responsive_control(
			'gap',
			array(
				'label'      => __( 'Gap', 'dealcraft' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => array( 'px' ),
				'range'      => array( 'px' => array( 'min' => 0, 'max' => 80 ) ),
				'default'    => array( 'unit' => 'px', 'size' => 24 ),
				'selectors'  => array(
					'{{WRAPPER}} .dealcraft-deals__grid' => 'gap: {{SIZE}}{{UNIT}};',
				),
			)
		);

		$this->add_control(
			'show_image',
			array(
				'label'        => __( 'Show Image', 'dealcraft' ),
				'type'         => Controls_Manager::SWITCHER,
				'default'      => 'yes',
				'return_value' => 'yes',
			)
		);

		$this->add_control(
			'show_price',
			array(
				'label'        => __( 'Show Pricing', 'dealcraft' ),
				'type'         => Controls_Manager::SWITCHER,
				'default'      => 'yes',
				'return_value' => 'yes',
			)
		);

		$this->add_control(
			'show_button',
			array(
				'label'        => __( 'Show Button', 'dealcraft' ),
				'type'         => Controls_Manager::SWITCHER,
				'default'      => 'yes',
				'return_value' => 'yes',
			)
		);

		$this->add_control(
			'nofollow',
			array(
				'label'        => __( 'Add rel="nofollow sponsored"', 'dealcraft' ),
				'type'         => Controls_Manager::SWITCHER,
				'default'      => 'yes',
				'return_value' => 'yes',
				'description'  => __( 'Recommended for affiliate links.', 'dealcraft' ),
				'condition'    => array( 'show_button' => 'yes' ),
			)
		);

		$this->end_controls_section();
	}

	/* ------------------------------------------------------------------ style */

	private function style_controls() {
		/* Heading */
		$this->start_controls_section(
			'section_style_heading',
			array(
				'label'     => __( 'Heading', 'dealcraft' ),
				'tab'       => Controls_Manager::TAB_STYLE,
				'condition' => array( 'show_heading' => 'yes' ),
			)
		);

		$this->add_control(
			'heading_color',
			array(
				'label'     => __( 'Color', 'dealcraft' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#7c8698',
				'selectors' => array(
					'{{WRAPPER}} .dealcraft-deals__heading' => 'color: {{VALUE}};',
				),
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'heading_typography',
				'selector' => '{{WRAPPER}} .dealcraft-deals__heading',
			)
		);

		$this->add_responsive_control(
			'heading_spacing',
			array(
				'label'      => __( 'Spacing Below', 'dealcraft' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => array( 'px' ),
				'range'      => array( 'px' => array( 'min' => 0, 'max' => 100 ) ),
				'default'    => array( 'unit' => 'px', 'size' => 24 ),
				'selectors'  => array(
					'{{WRAPPER}} .dealcraft-deals__heading' => 'margin-bottom: {{SIZE}}{{UNIT}};',
				),
			)
		);

		$this->end_controls_section();

		/* Card */
		$this->start_controls_section(
			'section_style_card',
			array(
				'label' => __( 'Card', 'dealcraft' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_control(
			'card_bg',
			array(
				'label'     => __( 'Background', 'dealcraft' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#ffffff',
				'selectors' => array(
					'{{WRAPPER}} .dealcraft-card' => 'background-color: {{VALUE}};',
				),
			)
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			array(
				'name'     => 'card_border',
				'selector' => '{{WRAPPER}} .dealcraft-card',
			)
		);

		$this->add_control(
			'card_radius',
			array(
				'label'      => __( 'Border Radius', 'dealcraft' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => array( 'px', '%' ),
				'default'    => array(
					'top'      => '18',
					'right'    => '18',
					'bottom'   => '18',
					'left'     => '18',
					'unit'     => 'px',
					'isLinked' => true,
				),
				'selectors'  => array(
					'{{WRAPPER}} .dealcraft-card' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);

		$this->add_responsive_control(
			'card_padding',
			array(
				'label'      => __( 'Padding', 'dealcraft' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => array( 'px', 'em' ),
				'default'    => array(
					'top'      => '28',
					'right'    => '28',
					'bottom'   => '28',
					'left'     => '28',
					'unit'     => 'px',
					'isLinked' => true,
				),
				'selectors'  => array(
					'{{WRAPPER}} .dealcraft-card' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			array(
				'name'     => 'card_shadow',
				'selector' => '{{WRAPPER}} .dealcraft-card',
			)
		);

		$this->end_controls_section();

		/* Content */
		$this->start_controls_section(
			'section_style_content',
			array(
				'label' => __( 'Card Content', 'dealcraft' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_responsive_control(
			'image_size',
			array(
				'label'      => __( 'Image Size', 'dealcraft' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => array( 'px' ),
				'range'      => array( 'px' => array( 'min' => 32, 'max' => 200 ) ),
				'default'    => array( 'unit' => 'px', 'size' => 72 ),
				'condition'  => array( 'show_image' => 'yes' ),
				'selectors'  => array(
					'{{WRAPPER}} .dealcraft-card__media' => 'width: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}};',
				),
			)
		);

		$this->add_control(
			'title_color',
			array(
				'label'     => __( 'Title Color', 'dealcraft' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#111827',
				'separator' => 'before',
				'selectors' => array(
					'{{WRAPPER}} .dealcraft-card__title' => 'color: {{VALUE}};',
				),
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'title_typography',
				'selector' => '{{WRAPPER}} .dealcraft-card__title',
			)
		);

		$this->add_control(
			'price_color',
			array(
				'label'     => __( 'Price Color', 'dealcraft' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#4f46e5',
				'separator' => 'before',
				'condition' => array( 'show_price' => 'yes' ),
				'selectors' => array(
					'{{WRAPPER}} .dealcraft-card__price' => 'color: {{VALUE}};',
				),
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'      => 'price_typography',
				'selector'  => '{{WRAPPER}} .dealcraft-card__price',
				'condition' => array( 'show_price' => 'yes' ),
			)
		);

		$this->add_control(
			'old_price_color',
			array(
				'label'     => __( 'Original Price Color', 'dealcraft' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#9ca3af',
				'condition' => array( 'show_price' => 'yes' ),
				'selectors' => array(
					'{{WRAPPER}} .dealcraft-card__old-price' => 'color: {{VALUE}};',
				),
			)
		);

		$this->end_controls_section();

		/* Button */
		$this->start_controls_section(
			'section_style_button',
			array(
				'label'     => __( 'Button', 'dealcraft' ),
				'tab'       => Controls_Manager::TAB_STYLE,
				'condition' => array( 'show_button' => 'yes' ),
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'card_button_typography',
				'selector' => '{{WRAPPER}} .dealcraft-card__button',
			)
		);

		$this->add_control(
			'button_bg',
			array(
				'label'     => __( 'Background', 'dealcraft' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#111827',
				'selectors' => array(
					'{{WRAPPER}} .dealcraft-card__button' => 'background-color: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'button_color',
			array(
				'label'     => __( 'Text Color', 'dealcraft' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#ffffff',
				'selectors' => array(
					'{{WRAPPER}} .dealcraft-card__button' => 'color: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'button_bg_hover',
			array(
				'label'     => __( 'Background (Hover)', 'dealcraft' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#4f46e5',
				'selectors' => array(
					'{{WRAPPER}} .dealcraft-card__button:hover' => 'background-color: {{VALUE}};',
				),
			)
		);

		$this->add_responsive_control(
			'card_button_padding',
			array(
				'label'      => __( 'Padding', 'dealcraft' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => array( 'px', 'em' ),
				'separator'  => 'before',
				'selectors'  => array(
					'{{WRAPPER}} .dealcraft-card__button' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);

		$this->add_control(
			'card_button_radius',
			array(
				'label'      => __( 'Border Radius', 'dealcraft' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => array( 'px', '%' ),
				'selectors'  => array(
					'{{WRAPPER}} .dealcraft-card__button' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);

		$this->end_controls_section();
	}

	/* ----------------------------------------------------------------- render */

	/**
	 * Builds the WP_Query args from the widget settings.
	 */
	private function build_query_args( $s ) {
		$args = array(
			'post_type'           => DEALCRAFT_CPT,
			'post_status'         => 'publish',
			'posts_per_page'      => ! empty( $s['limit'] ) ? (int) $s['limit'] : 6,
			'orderby'             => ! empty( $s['orderby'] ) ? $s['orderby'] : 'menu_order',
			'order'               => ! empty( $s['order'] ) ? $s['order'] : 'ASC',
			'ignore_sticky_posts' => true,
			'no_found_rows'       => true,
		);

		// menu_order alone leaves ties unordered; fall back to title.
		if ( 'menu_order' === $args['orderby'] ) {
			$args['orderby'] = 'menu_order title';
		}

		$categories = array_filter( (array) ( isset( $s['category'] ) ? $s['category'] : array() ) );
		if ( ! empty( $categories ) ) {
			$args['tax_query'] = array(
				array(
					'taxonomy' => DEALCRAFT_TAX,
					'field'    => 'term_id',
					'terms'    => array_map( 'intval', $categories ),
				),
			);
		}

		return $args;
	}

	protected function render() {
		$s     = $this->get_settings_for_display();
		$query = new WP_Query( $this->build_query_args( $s ) );

		if ( ! $query->have_posts() ) {
			if ( \Elementor\Plugin::$instance->editor->is_edit_mode() ) {
				echo '<div class="dealcraft-empty">'
					. esc_html__( 'No deals found for this selection. Add deals under DealCraft in the WordPress sidebar.', 'dealcraft' )
					. '</div>';
			}
			return;
		}

		$heading = $this->resolve_heading( $s );
		?>
		<div class="dealcraft-deals">
			<?php if ( 'yes' === $s['show_heading'] && '' !== $heading ) : ?>
				<h2 class="dealcraft-deals__heading"><?php echo esc_html( $heading ); ?></h2>
			<?php endif; ?>

			<div class="dealcraft-deals__grid">
				<?php
				while ( $query->have_posts() ) {
					$query->the_post();
					$this->render_card( DealCraft_Meta::get_deal_data( get_post() ), $s );
				}
				?>
			</div>
		</div>
		<?php
		wp_reset_postdata();
	}

	/** Explicit heading wins; otherwise use the single selected category's name. */
	private function resolve_heading( $s ) {
		if ( ! empty( $s['heading'] ) ) {
			return $s['heading'];
		}

		$categories = array_filter( (array) ( isset( $s['category'] ) ? $s['category'] : array() ) );
		if ( 1 === count( $categories ) ) {
			$term = get_term( (int) reset( $categories ), DEALCRAFT_TAX );
			if ( $term && ! is_wp_error( $term ) ) {
				return $term->name;
			}
		}

		return '';
	}

	private function render_card( $deal, $s ) {
		if ( empty( $deal ) ) {
			return;
		}
		?>
		<div class="dealcraft-card">
			<?php if ( '' !== $deal['badge'] ) : ?>
				<span class="dealcraft-card__badge"><?php echo esc_html( $deal['badge'] ); ?></span>
			<?php endif; ?>

			<?php if ( 'yes' === $s['show_image'] && $deal['image_id'] ) : ?>
				<div class="dealcraft-card__media">
					<?php
					echo wp_get_attachment_image(
						$deal['image_id'],
						'medium',
						false,
						array( 'class' => 'dealcraft-card__image', 'loading' => 'lazy' )
					);
					?>
				</div>
			<?php endif; ?>

			<div class="dealcraft-card__body">
				<h3 class="dealcraft-card__title"><?php echo esc_html( $deal['title'] ); ?></h3>

				<?php if ( 'yes' === $s['show_price'] && ( '' !== $deal['price'] || '' !== $deal['old_price'] ) ) : ?>
					<p class="dealcraft-card__pricing">
						<?php if ( '' !== $deal['price'] ) : ?>
							<span class="dealcraft-card__price"><?php echo esc_html( $deal['price'] ); ?></span>
						<?php endif; ?>
						<?php if ( '' !== $deal['old_price'] ) : ?>
							<s class="dealcraft-card__old-price"><?php echo esc_html( $deal['old_price'] ); ?></s>
						<?php endif; ?>
					</p>
				<?php endif; ?>

				<?php if ( 'yes' === $s['show_button'] && '' !== $deal['button_text'] ) : ?>
					<?php
					$url  = '' !== $deal['button_url'] ? $deal['button_url'] : get_permalink( $deal['id'] );
					$rel  = ( 'yes' === $s['nofollow'] ) ? 'nofollow sponsored noopener' : 'noopener';
					?>
					<a class="dealcraft-card__button"
						href="<?php echo esc_url( $url ); ?>"
						rel="<?php echo esc_attr( $rel ); ?>"
						<?php echo $deal['button_new'] ? 'target="_blank"' : ''; ?>>
						<?php echo esc_html( $deal['button_text'] ); ?>
					</a>
				<?php endif; ?>
			</div>
		</div>
		<?php
	}
}
