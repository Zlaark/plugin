<?php
/**
 * DealCraft Hero — an editable hero section widget for Elementor.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Background;
use Elementor\Group_Control_Box_Shadow;
use Elementor\Utils;

class DealCraft_Hero_Widget extends Widget_Base {

	public function get_name() {
		return 'dealcraft_hero';
	}

	public function get_title() {
		return __( 'DealCraft Hero', 'dealcraft' );
	}

	public function get_icon() {
		return 'eicon-banner';
	}

	public function get_categories() {
		return array( 'dealcraft' );
	}

	public function get_keywords() {
		return array( 'hero', 'banner', 'header', 'cta', 'dealcraft' );
	}

	public function get_style_depends() {
		return array( 'dealcraft-frontend' );
	}

	protected function register_controls() {
		$this->content_controls();
		$this->buttons_controls();
		$this->style_controls();
	}

	/* ---------------------------------------------------------------- content */

	private function content_controls() {
		$this->start_controls_section(
			'section_content',
			array(
				'label' => __( 'Content', 'dealcraft' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			)
		);

		$this->add_control(
			'eyebrow',
			array(
				'label'       => __( 'Eyebrow', 'dealcraft' ),
				'type'        => Controls_Manager::TEXT,
				'default'     => __( 'Discount Deals 2025', 'dealcraft' ),
				'placeholder' => __( 'Small label above the title', 'dealcraft' ),
				'label_block' => true,
			)
		);

		$this->add_control(
			'title',
			array(
				'label'       => __( 'Title', 'dealcraft' ),
				'type'        => Controls_Manager::TEXTAREA,
				'rows'        => 3,
				'default'     => __( 'Save big on the tools you already use', 'dealcraft' ),
				'label_block' => true,
			)
		);

		$this->add_control(
			'title_tag',
			array(
				'label'   => __( 'Title HTML Tag', 'dealcraft' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'h1',
				'options' => array(
					'h1'   => 'H1',
					'h2'   => 'H2',
					'h3'   => 'H3',
					'h4'   => 'H4',
					'div'  => 'div',
					'span' => 'span',
				),
			)
		);

		$this->add_control(
			'description',
			array(
				'label'   => __( 'Description', 'dealcraft' ),
				'type'    => Controls_Manager::TEXTAREA,
				'rows'    => 4,
				'default' => __( 'Hand-picked discounts on hosting, project management and analytics — verified and updated every month.', 'dealcraft' ),
			)
		);

		$this->add_control(
			'image',
			array(
				'label'   => __( 'Hero Image', 'dealcraft' ),
				'type'    => Controls_Manager::MEDIA,
				'default' => array(
					'url' => Utils::get_placeholder_image_src(),
				),
			)
		);

		$this->add_control(
			'layout',
			array(
				'label'   => __( 'Layout', 'dealcraft' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'image-right',
				'options' => array(
					'image-right'  => __( 'Text left / image right', 'dealcraft' ),
					'image-left'   => __( 'Image left / text right', 'dealcraft' ),
					'centered'     => __( 'Centered, image below', 'dealcraft' ),
					'text-only'    => __( 'Text only', 'dealcraft' ),
				),
			)
		);

		$this->add_responsive_control(
			'align',
			array(
				'label'     => __( 'Text Alignment', 'dealcraft' ),
				'type'      => Controls_Manager::CHOOSE,
				'options'   => array(
					'left'   => array(
						'title' => __( 'Left', 'dealcraft' ),
						'icon'  => 'eicon-text-align-left',
					),
					'center' => array(
						'title' => __( 'Center', 'dealcraft' ),
						'icon'  => 'eicon-text-align-center',
					),
					'right'  => array(
						'title' => __( 'Right', 'dealcraft' ),
						'icon'  => 'eicon-text-align-right',
					),
				),
				'selectors' => array(
					'{{WRAPPER}} .dealcraft-hero__content' => 'text-align: {{VALUE}};',
				),
			)
		);

		$this->end_controls_section();
	}

	private function buttons_controls() {
		$this->start_controls_section(
			'section_buttons',
			array(
				'label' => __( 'Buttons', 'dealcraft' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			)
		);

		$this->add_control(
			'primary_text',
			array(
				'label'   => __( 'Primary Button Text', 'dealcraft' ),
				'type'    => Controls_Manager::TEXT,
				'default' => __( 'Browse Deals', 'dealcraft' ),
			)
		);

		$this->add_control(
			'primary_link',
			array(
				'label'       => __( 'Primary Button Link', 'dealcraft' ),
				'type'        => Controls_Manager::URL,
				'default'     => array( 'url' => '#' ),
				'placeholder' => 'https://example.com',
			)
		);

		$this->add_control(
			'secondary_text',
			array(
				'label'     => __( 'Secondary Button Text', 'dealcraft' ),
				'type'      => Controls_Manager::TEXT,
				'default'   => '',
				'separator' => 'before',
			)
		);

		$this->add_control(
			'secondary_link',
			array(
				'label'     => __( 'Secondary Button Link', 'dealcraft' ),
				'type'      => Controls_Manager::URL,
				'condition' => array( 'secondary_text!' => '' ),
			)
		);

		$this->end_controls_section();
	}

	/* ------------------------------------------------------------------ style */

	private function style_controls() {
		$this->start_controls_section(
			'section_style_box',
			array(
				'label' => __( 'Box', 'dealcraft' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			array(
				'name'     => 'hero_background',
				'selector' => '{{WRAPPER}} .dealcraft-hero',
			)
		);

		$this->add_responsive_control(
			'hero_padding',
			array(
				'label'      => __( 'Padding', 'dealcraft' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => array( 'px', 'em', '%' ),
				'default'    => array(
					'top'      => '80',
					'right'    => '32',
					'bottom'   => '80',
					'left'     => '32',
					'unit'     => 'px',
					'isLinked' => false,
				),
				'selectors'  => array(
					'{{WRAPPER}} .dealcraft-hero' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);

		$this->add_control(
			'hero_radius',
			array(
				'label'      => __( 'Border Radius', 'dealcraft' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => array( 'px', '%' ),
				'selectors'  => array(
					'{{WRAPPER}} .dealcraft-hero' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);

		$this->add_responsive_control(
			'content_gap',
			array(
				'label'      => __( 'Column Gap', 'dealcraft' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => array( 'px' ),
				'range'      => array( 'px' => array( 'min' => 0, 'max' => 160 ) ),
				'default'    => array( 'unit' => 'px', 'size' => 56 ),
				'selectors'  => array(
					'{{WRAPPER}} .dealcraft-hero__inner' => 'gap: {{SIZE}}{{UNIT}};',
				),
			)
		);

		$this->end_controls_section();

		/* Typography ---------------------------------------------------- */

		$this->start_controls_section(
			'section_style_text',
			array(
				'label' => __( 'Typography', 'dealcraft' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_control(
			'eyebrow_color',
			array(
				'label'     => __( 'Eyebrow Color', 'dealcraft' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#7c8698',
				'selectors' => array(
					'{{WRAPPER}} .dealcraft-hero__eyebrow' => 'color: {{VALUE}};',
				),
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'eyebrow_typography',
				'selector' => '{{WRAPPER}} .dealcraft-hero__eyebrow',
			)
		);

		$this->add_control(
			'title_color',
			array(
				'label'     => __( 'Title Color', 'dealcraft' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#111827',
				'separator' => 'before',
				'selectors' => array(
					'{{WRAPPER}} .dealcraft-hero__title' => 'color: {{VALUE}};',
				),
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'title_typography',
				'selector' => '{{WRAPPER}} .dealcraft-hero__title',
			)
		);

		$this->add_control(
			'desc_color',
			array(
				'label'     => __( 'Description Color', 'dealcraft' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#4b5563',
				'separator' => 'before',
				'selectors' => array(
					'{{WRAPPER}} .dealcraft-hero__desc' => 'color: {{VALUE}};',
				),
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'desc_typography',
				'selector' => '{{WRAPPER}} .dealcraft-hero__desc',
			)
		);

		$this->end_controls_section();

		/* Buttons ------------------------------------------------------- */

		$this->start_controls_section(
			'section_style_buttons',
			array(
				'label' => __( 'Buttons', 'dealcraft' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'button_typography',
				'selector' => '{{WRAPPER}} .dealcraft-btn',
			)
		);

		$this->add_responsive_control(
			'button_padding',
			array(
				'label'      => __( 'Padding', 'dealcraft' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => array( 'px', 'em' ),
				'selectors'  => array(
					'{{WRAPPER}} .dealcraft-btn' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);

		$this->add_control(
			'button_radius',
			array(
				'label'      => __( 'Border Radius', 'dealcraft' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => array( 'px', '%' ),
				'selectors'  => array(
					'{{WRAPPER}} .dealcraft-btn' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);

		$this->add_control(
			'primary_bg',
			array(
				'label'     => __( 'Primary Background', 'dealcraft' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#111827',
				'separator' => 'before',
				'selectors' => array(
					'{{WRAPPER}} .dealcraft-btn--primary' => 'background-color: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'primary_color',
			array(
				'label'     => __( 'Primary Text Color', 'dealcraft' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#ffffff',
				'selectors' => array(
					'{{WRAPPER}} .dealcraft-btn--primary' => 'color: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'primary_bg_hover',
			array(
				'label'     => __( 'Primary Background (Hover)', 'dealcraft' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .dealcraft-btn--primary:hover' => 'background-color: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'secondary_color',
			array(
				'label'     => __( 'Secondary Text Color', 'dealcraft' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#111827',
				'separator' => 'before',
				'condition' => array( 'secondary_text!' => '' ),
				'selectors' => array(
					'{{WRAPPER}} .dealcraft-btn--secondary' => 'color: {{VALUE}}; border-color: {{VALUE}};',
				),
			)
		);

		$this->end_controls_section();

		/* Image --------------------------------------------------------- */

		$this->start_controls_section(
			'section_style_image',
			array(
				'label'     => __( 'Image', 'dealcraft' ),
				'tab'       => Controls_Manager::TAB_STYLE,
				'condition' => array( 'layout!' => 'text-only' ),
			)
		);

		$this->add_responsive_control(
			'image_width',
			array(
				'label'      => __( 'Max Width', 'dealcraft' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => array( 'px', '%' ),
				'range'      => array(
					'px' => array( 'min' => 100, 'max' => 1200 ),
					'%'  => array( 'min' => 10, 'max' => 100 ),
				),
				'default'    => array( 'unit' => '%', 'size' => 100 ),
				'selectors'  => array(
					'{{WRAPPER}} .dealcraft-hero__media img' => 'max-width: {{SIZE}}{{UNIT}};',
				),
			)
		);

		$this->add_control(
			'image_radius',
			array(
				'label'      => __( 'Border Radius', 'dealcraft' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => array( 'px', '%' ),
				'default'    => array(
					'top'      => '18',
					'right'    => '18',
					'bottom'   => '18',
					'left'     => '18',
					'unit'     => 'px',
					'isLinked' => true,
				),
				'selectors'  => array(
					'{{WRAPPER}} .dealcraft-hero__media img' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			array(
				'name'     => 'image_shadow',
				'selector' => '{{WRAPPER}} .dealcraft-hero__media img',
			)
		);

		$this->end_controls_section();
	}

	/* ----------------------------------------------------------------- render */

	protected function render() {
		$s      = $this->get_settings_for_display();
		$layout = ! empty( $s['layout'] ) ? $s['layout'] : 'image-right';

		$this->add_render_attribute(
			'wrapper',
			'class',
			array( 'dealcraft-hero', 'dealcraft-hero--' . $layout )
		);

		$has_image = ( 'text-only' !== $layout ) && ! empty( $s['image']['url'] );
		?>
		<div <?php $this->print_render_attribute_string( 'wrapper' ); ?>>
			<div class="dealcraft-hero__inner">

				<div class="dealcraft-hero__content">
					<?php if ( ! empty( $s['eyebrow'] ) ) : ?>
						<p class="dealcraft-hero__eyebrow"><?php echo esc_html( $s['eyebrow'] ); ?></p>
					<?php endif; ?>

					<?php
					if ( ! empty( $s['title'] ) ) {
						$tag = ! empty( $s['title_tag'] ) ? $s['title_tag'] : 'h1';
						printf(
							'<%1$s class="dealcraft-hero__title">%2$s</%1$s>',
							esc_attr( $tag ),
							wp_kses_post( $s['title'] )
						);
					}
					?>

					<?php if ( ! empty( $s['description'] ) ) : ?>
						<div class="dealcraft-hero__desc"><?php echo wp_kses_post( wpautop( $s['description'] ) ); ?></div>
					<?php endif; ?>

					<?php if ( ! empty( $s['primary_text'] ) || ! empty( $s['secondary_text'] ) ) : ?>
						<div class="dealcraft-hero__actions">
							<?php
							$this->render_button( 'primary', $s['primary_text'], $s['primary_link'] );
							$this->render_button( 'secondary', $s['secondary_text'], $s['secondary_link'] );
							?>
						</div>
					<?php endif; ?>
				</div>

				<?php if ( $has_image ) : ?>
					<div class="dealcraft-hero__media">
						<img src="<?php echo esc_url( $s['image']['url'] ); ?>"
							alt="<?php echo esc_attr( dealcraft_media_alt( $s['image'] ) ); ?>" />
					</div>
				<?php endif; ?>

			</div>
		</div>
		<?php
	}

	/**
	 * @param string $variant primary|secondary
	 * @param string $text
	 * @param array  $link    Elementor URL control value.
	 */
	private function render_button( $variant, $text, $link ) {
		if ( empty( $text ) ) {
			return;
		}

		$key = 'btn_' . $variant;
		$this->add_render_attribute( $key, 'class', array( 'dealcraft-btn', 'dealcraft-btn--' . $variant ) );

		if ( ! empty( $link['url'] ) ) {
			$this->add_link_attributes( $key, $link );
		}

		printf(
			'<a %1$s>%2$s</a>',
			$this->get_render_attribute_string( $key ), // phpcs:ignore WordPress.Security.EscapeOutput
			esc_html( $text )
		);
	}
}

/**
 * Elementor stores the alt text on the attachment, not in the control value.
 * Small helper so the hero image always ships an alt attribute.
 */
function dealcraft_media_alt( $media ) {
	if ( ! empty( $media['id'] ) ) {
		$alt = get_post_meta( (int) $media['id'], '_wp_attachment_image_alt', true );
		if ( $alt ) {
			return $alt;
		}
	}
	return '';
}
