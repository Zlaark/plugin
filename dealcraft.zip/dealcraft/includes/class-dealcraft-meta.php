<?php
/**
 * The "Deal Details" meta box: image, pricing, old pricing, button label/URL.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class DealCraft_Meta {

	/** Meta key => sanitize callback. */
	const FIELDS = array(
		'_dealcraft_image_id'    => 'absint',
		'_dealcraft_price'       => 'sanitize_text_field',
		'_dealcraft_old_price'   => 'sanitize_text_field',
		'_dealcraft_badge'       => 'sanitize_text_field',
		'_dealcraft_button_text' => 'sanitize_text_field',
		'_dealcraft_button_url'  => 'esc_url_raw',
		'_dealcraft_button_new'  => 'absint',
	);

	public static function init() {
		add_action( 'add_meta_boxes', array( __CLASS__, 'add_meta_box' ) );
		add_action( 'save_post_' . DEALCRAFT_CPT, array( __CLASS__, 'save' ), 10, 2 );
		add_action( 'init', array( __CLASS__, 'register_meta' ) );
	}

	/** Exposes the fields to the REST API so Elementor/blocks can read them. */
	public static function register_meta() {
		foreach ( self::FIELDS as $key => $sanitize ) {
			register_post_meta(
				DEALCRAFT_CPT,
				$key,
				array(
					'show_in_rest'      => true,
					'single'            => true,
					'type'              => ( 'absint' === $sanitize ) ? 'integer' : 'string',
					'sanitize_callback' => $sanitize,
					'auth_callback'     => function () {
						return current_user_can( 'edit_posts' );
					},
				)
			);
		}
	}

	public static function add_meta_box() {
		add_meta_box(
			'dealcraft_details',
			__( 'Deal Details', 'dealcraft' ),
			array( __CLASS__, 'render' ),
			DEALCRAFT_CPT,
			'normal',
			'high'
		);
	}

	public static function render( $post ) {
		wp_nonce_field( 'dealcraft_save_meta', 'dealcraft_meta_nonce' );

		$image_id    = (int) get_post_meta( $post->ID, '_dealcraft_image_id', true );
		$price       = get_post_meta( $post->ID, '_dealcraft_price', true );
		$old_price   = get_post_meta( $post->ID, '_dealcraft_old_price', true );
		$badge       = get_post_meta( $post->ID, '_dealcraft_badge', true );
		$button_text = get_post_meta( $post->ID, '_dealcraft_button_text', true );
		$button_url  = get_post_meta( $post->ID, '_dealcraft_button_url', true );
		$button_new  = (int) get_post_meta( $post->ID, '_dealcraft_button_new', true );

		$preview = $image_id ? wp_get_attachment_image_url( $image_id, 'thumbnail' ) : '';
		?>
		<div class="dealcraft-fields">

			<div class="dealcraft-field dealcraft-field--image">
				<label><?php esc_html_e( 'Deal Image / Logo', 'dealcraft' ); ?></label>
				<div class="dealcraft-image-box">
					<div class="dealcraft-image-preview <?php echo $preview ? '' : 'is-empty'; ?>">
						<?php if ( $preview ) : ?>
							<img src="<?php echo esc_url( $preview ); ?>" alt="" />
						<?php else : ?>
							<span><?php esc_html_e( 'No image selected', 'dealcraft' ); ?></span>
						<?php endif; ?>
					</div>
					<div class="dealcraft-image-actions">
						<button type="button" class="button dealcraft-select-image">
							<?php esc_html_e( 'Select image', 'dealcraft' ); ?>
						</button>
						<button type="button" class="button-link dealcraft-remove-image" <?php echo $image_id ? '' : 'style="display:none"'; ?>>
							<?php esc_html_e( 'Remove', 'dealcraft' ); ?>
						</button>
					</div>
					<input type="hidden" class="dealcraft-image-id" name="dealcraft_image_id" value="<?php echo esc_attr( $image_id ); ?>" />
				</div>
			</div>

			<div class="dealcraft-row">
				<div class="dealcraft-field">
					<label for="dealcraft_price"><?php esc_html_e( 'Pricing', 'dealcraft' ); ?></label>
					<input type="text" id="dealcraft_price" name="dealcraft_price"
						value="<?php echo esc_attr( $price ); ?>" placeholder="$2.59/mo" />
					<p class="description"><?php esc_html_e( 'Shown as the highlighted price. Free text, e.g. "$20.00/mo" or "Free Forever".', 'dealcraft' ); ?></p>
				</div>

				<div class="dealcraft-field">
					<label for="dealcraft_old_price"><?php esc_html_e( 'Original Price', 'dealcraft' ); ?></label>
					<input type="text" id="dealcraft_old_price" name="dealcraft_old_price"
						value="<?php echo esc_attr( $old_price ); ?>" placeholder="$4.95" />
					<p class="description"><?php esc_html_e( 'Optional. Rendered struck through next to the price.', 'dealcraft' ); ?></p>
				</div>
			</div>

			<div class="dealcraft-field">
				<label for="dealcraft_badge"><?php esc_html_e( 'Badge', 'dealcraft' ); ?></label>
				<input type="text" id="dealcraft_badge" name="dealcraft_badge"
					value="<?php echo esc_attr( $badge ); ?>" placeholder="<?php esc_attr_e( 'e.g. Best Value', 'dealcraft' ); ?>" />
				<p class="description"><?php esc_html_e( 'Optional ribbon shown on the card corner.', 'dealcraft' ); ?></p>
			</div>

			<div class="dealcraft-row">
				<div class="dealcraft-field">
					<label for="dealcraft_button_text"><?php esc_html_e( 'Button Text', 'dealcraft' ); ?></label>
					<input type="text" id="dealcraft_button_text" name="dealcraft_button_text"
						value="<?php echo esc_attr( $button_text ); ?>" placeholder="Grab Deal" />
				</div>

				<div class="dealcraft-field">
					<label for="dealcraft_button_url"><?php esc_html_e( 'Button URL', 'dealcraft' ); ?></label>
					<input type="url" id="dealcraft_button_url" name="dealcraft_button_url"
						value="<?php echo esc_attr( $button_url ); ?>" placeholder="https://example.com/offer" />
				</div>
			</div>

			<div class="dealcraft-field">
				<label class="dealcraft-checkbox">
					<input type="checkbox" name="dealcraft_button_new" value="1" <?php checked( $button_new, 1 ); ?> />
					<?php esc_html_e( 'Open the button link in a new tab', 'dealcraft' ); ?>
				</label>
			</div>

			<p class="dealcraft-hint">
				<?php esc_html_e( 'Assign this deal to a category in the "Deal Categories" box — the Elementor widget filters by that category.', 'dealcraft' ); ?>
			</p>
		</div>
		<?php
	}

	public static function save( $post_id, $post ) {
		if ( ! isset( $_POST['dealcraft_meta_nonce'] ) ) {
			return;
		}
		if ( ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['dealcraft_meta_nonce'] ) ), 'dealcraft_save_meta' ) ) {
			return;
		}
		if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
			return;
		}
		if ( ! current_user_can( 'edit_post', $post_id ) ) {
			return;
		}

		foreach ( self::FIELDS as $meta_key => $sanitize ) {
			// _dealcraft_price -> dealcraft_price
			$input_name = ltrim( $meta_key, '_' );

			if ( '_dealcraft_button_new' === $meta_key ) {
				// Unchecked checkboxes are simply absent from the request.
				update_post_meta( $post_id, $meta_key, isset( $_POST[ $input_name ] ) ? 1 : 0 );
				continue;
			}

			if ( ! isset( $_POST[ $input_name ] ) ) {
				continue;
			}

			$value = call_user_func( $sanitize, wp_unslash( $_POST[ $input_name ] ) );

			if ( '' === $value || 0 === $value ) {
				delete_post_meta( $post_id, $meta_key );
			} else {
				update_post_meta( $post_id, $meta_key, $value );
			}
		}
	}

	/**
	 * Normalized data for one deal, ready for the frontend templates.
	 *
	 * @param int|WP_Post $post
	 * @return array
	 */
	public static function get_deal_data( $post ) {
		$post = get_post( $post );
		if ( ! $post ) {
			return array();
		}

		$image_id = (int) get_post_meta( $post->ID, '_dealcraft_image_id', true );
		if ( ! $image_id && has_post_thumbnail( $post->ID ) ) {
			$image_id = (int) get_post_thumbnail_id( $post->ID );
		}

		return array(
			'id'          => $post->ID,
			'title'       => get_the_title( $post ),
			'image_id'    => $image_id,
			'price'       => (string) get_post_meta( $post->ID, '_dealcraft_price', true ),
			'old_price'   => (string) get_post_meta( $post->ID, '_dealcraft_old_price', true ),
			'badge'       => (string) get_post_meta( $post->ID, '_dealcraft_badge', true ),
			'button_text' => (string) get_post_meta( $post->ID, '_dealcraft_button_text', true ),
			'button_url'  => (string) get_post_meta( $post->ID, '_dealcraft_button_url', true ),
			'button_new'  => (bool) get_post_meta( $post->ID, '_dealcraft_button_new', true ),
			'terms'       => wp_get_post_terms( $post->ID, DEALCRAFT_TAX, array( 'fields' => 'ids' ) ),
		);
	}
}
