<?php
/**
 * Elementor bootstrap: adds a "DealCraft" widget category and registers the
 * Hero and Deals Grid widgets.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class DealCraft_Elementor {

	const MIN_ELEMENTOR_VERSION = '3.5.0';

	public static function init() {
		add_action( 'plugins_loaded', array( __CLASS__, 'boot' ), 20 );
	}

	public static function boot() {
		if ( ! did_action( 'elementor/loaded' ) ) {
			add_action( 'admin_notices', array( __CLASS__, 'notice_missing_elementor' ) );
			return;
		}

		if ( version_compare( ELEMENTOR_VERSION, self::MIN_ELEMENTOR_VERSION, '<' ) ) {
			add_action( 'admin_notices', array( __CLASS__, 'notice_old_elementor' ) );
			return;
		}

		add_action( 'elementor/elements/categories_registered', array( __CLASS__, 'register_category' ) );
		add_action( 'elementor/widgets/register', array( __CLASS__, 'register_widgets' ) );
		add_action( 'elementor/frontend/after_enqueue_styles', array( __CLASS__, 'enqueue_styles' ) );
	}

	public static function register_category( $manager ) {
		$manager->add_category(
			'dealcraft',
			array(
				'title' => __( 'DealCraft', 'dealcraft' ),
				'icon'  => 'eicon-price-table',
			)
		);
	}

	public static function register_widgets( $widgets_manager ) {
		require_once DEALCRAFT_PATH . 'widgets/class-dealcraft-hero-widget.php';
		require_once DEALCRAFT_PATH . 'widgets/class-dealcraft-deals-widget.php';

		$widgets_manager->register( new DealCraft_Hero_Widget() );
		$widgets_manager->register( new DealCraft_Deals_Widget() );
	}

	public static function enqueue_styles() {
		wp_enqueue_style(
			'dealcraft-frontend',
			DEALCRAFT_URL . 'assets/css/frontend.css',
			array(),
			DEALCRAFT_VERSION
		);
	}

	public static function notice_missing_elementor() {
		if ( ! current_user_can( 'activate_plugins' ) ) {
			return;
		}
		echo '<div class="notice notice-warning"><p>';
		echo esc_html__( 'DealCraft: Elementor is not active. The Deals manager still works, but the Hero and Deals Grid widgets need Elementor.', 'dealcraft' );
		echo '</p></div>';
	}

	public static function notice_old_elementor() {
		if ( ! current_user_can( 'activate_plugins' ) ) {
			return;
		}
		echo '<div class="notice notice-warning"><p>';
		printf(
			/* translators: %s: minimum Elementor version */
			esc_html__( 'DealCraft requires Elementor %s or newer.', 'dealcraft' ),
			esc_html( self::MIN_ELEMENTOR_VERSION )
		);
		echo '</p></div>';
	}
}
