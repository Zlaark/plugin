<?php
/**
 * Registers the "Deals" post type and its category taxonomy, and adds the
 * admin list-table columns that make the deals manageable from the sidebar.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class DealCraft_Post_Type {

	/** Categories created on activation so the plugin is usable out of the box. */
	const DEFAULT_TERMS = array(
		'discount-deals' => 'Discount Deals',
		'web-hosting'    => 'Web Hosting',
	);

	public static function init() {
		add_action( 'init', array( __CLASS__, 'register_post_type' ) );
		add_action( 'init', array( __CLASS__, 'register_taxonomy' ) );
		add_action( 'init', array( __CLASS__, 'maybe_seed_default_terms' ), 20 );

		add_filter( 'manage_' . DEALCRAFT_CPT . '_posts_columns', array( __CLASS__, 'columns' ) );
		add_action( 'manage_' . DEALCRAFT_CPT . '_posts_custom_column', array( __CLASS__, 'column_content' ), 10, 2 );
		add_filter( 'enter_title_here', array( __CLASS__, 'title_placeholder' ), 10, 2 );
	}

	public static function register_post_type() {
		$labels = array(
			'name'               => __( 'Deals', 'dealcraft' ),
			'singular_name'      => __( 'Deal', 'dealcraft' ),
			'menu_name'          => __( 'DealCraft', 'dealcraft' ),
			'add_new'            => __( 'Add Deal', 'dealcraft' ),
			'add_new_item'       => __( 'Add New Deal', 'dealcraft' ),
			'edit_item'          => __( 'Edit Deal', 'dealcraft' ),
			'new_item'           => __( 'New Deal', 'dealcraft' ),
			'view_item'          => __( 'View Deal', 'dealcraft' ),
			'search_items'       => __( 'Search Deals', 'dealcraft' ),
			'not_found'          => __( 'No deals found.', 'dealcraft' ),
			'not_found_in_trash' => __( 'No deals found in Trash.', 'dealcraft' ),
			'all_items'          => __( 'All Deals', 'dealcraft' ),
		);

		register_post_type(
			DEALCRAFT_CPT,
			array(
				'labels'          => $labels,
				'public'          => true,
				'has_archive'     => false,
				'show_ui'         => true,
				'show_in_menu'    => true,
				'show_in_rest'    => true,
				'menu_position'   => 26,
				'menu_icon'       => 'dashicons-tag',
				'supports'        => array( 'title', 'thumbnail', 'page-attributes' ),
				'rewrite'         => array( 'slug' => 'deal' ),
				'capability_type' => 'post',
			)
		);
	}

	public static function register_taxonomy() {
		$labels = array(
			'name'              => __( 'Deal Categories', 'dealcraft' ),
			'singular_name'     => __( 'Deal Category', 'dealcraft' ),
			'menu_name'         => __( 'Categories', 'dealcraft' ),
			'all_items'         => __( 'All Categories', 'dealcraft' ),
			'edit_item'         => __( 'Edit Category', 'dealcraft' ),
			'update_item'       => __( 'Update Category', 'dealcraft' ),
			'add_new_item'      => __( 'Add New Category', 'dealcraft' ),
			'new_item_name'     => __( 'New Category Name', 'dealcraft' ),
			'search_items'      => __( 'Search Categories', 'dealcraft' ),
		);

		register_taxonomy(
			DEALCRAFT_TAX,
			array( DEALCRAFT_CPT ),
			array(
				'labels'            => $labels,
				'hierarchical'      => true,
				'public'            => true,
				'show_ui'           => true,
				'show_admin_column' => true,
				'show_in_rest'      => true,
				'rewrite'           => array( 'slug' => 'deal-category' ),
			)
		);
	}

	/**
	 * Creates the default categories once. Runs on activation and, as a safety
	 * net, on init for installs where the activation hook never fired (e.g. the
	 * plugin folder was dropped in via FTP and activated by a must-use loader).
	 */
	public static function maybe_seed_default_terms() {
		if ( get_option( 'dealcraft_defaults_seeded' ) ) {
			return;
		}
		self::seed_default_terms();
	}

	public static function seed_default_terms() {
		foreach ( self::DEFAULT_TERMS as $slug => $name ) {
			if ( ! term_exists( $slug, DEALCRAFT_TAX ) ) {
				wp_insert_term( $name, DEALCRAFT_TAX, array( 'slug' => $slug ) );
			}
		}
		update_option( 'dealcraft_defaults_seeded', 1 );
	}

	public static function columns( $columns ) {
		$reordered = array();
		foreach ( $columns as $key => $label ) {
			if ( 'title' === $key ) {
				$reordered['dealcraft_image'] = __( 'Image', 'dealcraft' );
			}
			$reordered[ $key ] = $label;
			if ( 'title' === $key ) {
				$reordered['dealcraft_price'] = __( 'Pricing', 'dealcraft' );
			}
		}
		return $reordered;
	}

	public static function column_content( $column, $post_id ) {
		if ( 'dealcraft_image' === $column ) {
			$image_id = (int) get_post_meta( $post_id, '_dealcraft_image_id', true );
			if ( $image_id ) {
				echo wp_get_attachment_image( $image_id, array( 48, 48 ), false, array( 'class' => 'dealcraft-col-thumb' ) );
			} else {
				echo '<span class="dealcraft-col-thumb dealcraft-col-thumb--empty">&mdash;</span>';
			}
		}

		if ( 'dealcraft_price' === $column ) {
			$price     = get_post_meta( $post_id, '_dealcraft_price', true );
			$old_price = get_post_meta( $post_id, '_dealcraft_old_price', true );
			if ( '' === $price && '' === $old_price ) {
				echo '&mdash;';
				return;
			}
			echo '<strong>' . esc_html( $price ) . '</strong>';
			if ( '' !== $old_price ) {
				echo ' <s style="opacity:.6">' . esc_html( $old_price ) . '</s>';
			}
		}
	}

	public static function title_placeholder( $title, $post ) {
		if ( $post && DEALCRAFT_CPT === $post->post_type ) {
			return __( 'Deal title (e.g. ClickUp — Project Management)', 'dealcraft' );
		}
		return $title;
	}

	/**
	 * Returns [ term_id => name ] for every deal category — used to build the
	 * category dropdown inside the Elementor widget controls.
	 */
	public static function get_category_options() {
		$options = array();
		$terms   = get_terms(
			array(
				'taxonomy'   => DEALCRAFT_TAX,
				'hide_empty' => false,
			)
		);

		if ( is_wp_error( $terms ) ) {
			return $options;
		}

		foreach ( $terms as $term ) {
			$options[ $term->term_id ] = $term->name;
		}
		return $options;
	}
}
