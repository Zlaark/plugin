/* DealCraft — wires the WP media library into the Deal Details meta box. */
( function ( $ ) {
	'use strict';

	var frame = null;

	$( document ).on( 'click', '.dealcraft-select-image', function ( e ) {
		e.preventDefault();

		var $box = $( this ).closest( '.dealcraft-image-box' );

		// Reusing a single frame keeps the modal snappy across repeated opens.
		if ( frame ) {
			frame.off( 'select' );
		} else {
			frame = wp.media( {
				title: DealCraftAdmin.chooseImage,
				button: { text: DealCraftAdmin.useImage },
				library: { type: 'image' },
				multiple: false
			} );
		}

		frame.on( 'select', function () {
			var attachment = frame.state().get( 'selection' ).first().toJSON(),
				url = attachment.sizes && attachment.sizes.thumbnail
					? attachment.sizes.thumbnail.url
					: attachment.url;

			$box.find( '.dealcraft-image-id' ).val( attachment.id );
			$box.find( '.dealcraft-image-preview' )
				.removeClass( 'is-empty' )
				.html( $( '<img>' ).attr( { src: url, alt: '' } ) );
			$box.find( '.dealcraft-remove-image' ).show();
		} );

		frame.open();
	} );

	$( document ).on( 'click', '.dealcraft-remove-image', function ( e ) {
		e.preventDefault();

		var $box = $( this ).closest( '.dealcraft-image-box' );

		$box.find( '.dealcraft-image-id' ).val( '' );
		$box.find( '.dealcraft-image-preview' )
			.addClass( 'is-empty' )
			.html( $( '<span>' ).text( 'No image selected' ) );
		$( this ).hide();
	} );
} )( jQuery );
